package kvpaxos

//
// any additions to Clerk state
//
type ClerkImpl struct {
}

//
// initialize ck.impl state
//
func (ck *Clerk) InitImpl() {
}

//
// fetch the current value for a key.
// returns "" if the key does not exist.
// keeps trying forever in the face of all other errors.
//
func (ck *Clerk) Get(key string) string {
	return ""
}

//
// shared by Put and Append; op is either "Put" or "Append"
//
func (ck *Clerk) PutAppend(key string, value string, op string) {
}
