package kvpaxos

//
// Define what goes into "value" that Paxos is used to agree upon.
// Field names must start with capital letters,
// otherwise RPC will break.
//
type Op struct {
}

//
// additions to KVPaxos state
//
type KVPaxosImpl struct {
}

//
// initialize kv.impl.*
//
func (kv *KVPaxos) InitImpl() {
}

//
// Handler for Get RPCs
//
func (kv *KVPaxos) Get(args *GetArgs, reply *GetReply) error {
	return nil
}

//
// Handler for Put and Append RPCs
//
func (kv *KVPaxos) PutAppend(args *PutAppendArgs, reply *PutAppendReply) error {
	return nil
}

//
// Execute operation encoded in decided value v and update local state
//
func (kv *KVPaxos) ApplyOp(v interface{}) {
}
